<?php
require_once 'config/db.php';

// Create database instance
$database = new Database();
$db = $database->getConnection();

// Example SELECT query
$results = $database->select("SELECT * FROM products WHERE category_id = ?", [1]);

// Example INSERT query
$newId = $database->insert(
    "INSERT INTO users (full_name, email) VALUES (?, ?)",
    ["John Doe", "john@example.com"]
);

// Close connection when done
$database->closeConnection();