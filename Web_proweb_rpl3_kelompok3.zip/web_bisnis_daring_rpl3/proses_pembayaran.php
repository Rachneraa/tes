<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Anda harus login!']);
    exit();
}

require 'koneksi.php';

$nama = trim($_POST['nama'] ?? '');
$email = trim($_POST['email'] ?? '');
$alamat = trim($_POST['alamat'] ?? '');
$metode = trim($_POST['metode'] ?? '');

if (empty($nama) || empty($email) || empty($alamat) || empty($metode)) {
    echo json_encode(['success' => false, 'message' => 'Semua field wajib diisi!']);
    exit();
}

// Contoh: Simpan ke tabel orders (buat tabel orders jika belum ada)
$stmt = $conn->prepare("INSERT INTO orders (user_id, nama, email, alamat, metode, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("issss", $_SESSION['user_id'], $nama, $email, $alamat, $metode);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Pembayaran berhasil!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan pembayaran.']);
}
$stmt->close();