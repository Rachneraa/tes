// =====================
// DATA PRODUK
// =====================
const products = [
    {
        id: 1,
        name: "Kemeja Slim Fit Lengan Panjang",
        category: "Pria",
        price: 249000,
        originalPrice: 299000,
        discount: 17,
        image: "https://images.unsplash.com/photo-1598032895397-b9472444bf93",
        badge: "TERBARU",
        description: "Kemeja slim fit dengan bahan katun premium yang nyaman dipakai. Tersedia dalam berbagai pilihan warna. Cocok untuk acara formal maupun casual.",
        sizes: ['S', 'M', 'L', 'XL']
    },
    {
        id: 2,
        name: "Blouse Wanita Floral",
        category: "Wanita",
        price: 189000,
        originalPrice: 229000,
        image: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3",
        description: "Blouse wanita dengan motif floral yang cantik. Bahan ringan dan breathable, sempurna untuk daily wear. Design yang feminim dan elegan.",
        sizes: ['S', 'M', 'L']
    },
    {
        id: 3,
        name: "Hoodie Unisex Hitam",
        category: "Pria",
        price: 299000,
        originalPrice: 399000,
        image: "https://images.unsplash.com/photo-1578681994506-b8f463449011?auto=format&fit=crop&w=800&q=80",
        badge: "POPULER"
    },
    {
        id: 4,
        name: "Rok Wanita Mid Length",
        category: "Wanita",
        price: 179000,
        originalPrice: 219000,
        discount: 18,
        image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80"
    },
    {
        id: 5,
        name: "Celana Chino Slim Fit",
        category: "Pria",
        price: 279000,
        originalPrice: 329000,
        image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=800&q=80",
    },
    {
        id: 6,
        name: "Dress Wanita Polos",
        category: "Wanita",
        price: 349000,
        originalPrice: 429000,
        discount: 19,
        image: "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
    },
    {
        id: 7,
        name: "T-shirt Anak Kartun",
        category: "Anak",
        price: 99000,
        originalPrice: 129000,
        discount: 23,
        image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1515&q=80"
    },
    
];

const sepatuProducts = [
    {
        id: 101,
        name: "Sneakers Putih Klasik",
        price: 399000,
        originalPrice: 499000,
        discount: 20,
        image: "https://images.unsplash.com/photo-1517260911205-8c1e1b6e1b8c",
        badge: "BEST SELLER",
        description: "Sneakers putih klasik dengan sol yang nyaman. Material premium dan tahan lama. Cocok untuk gaya casual sehari-hari.",
        sizes: ['38', '39', '40', '41', '42', '43']
    },
    {
        id: 102,
        name: "Sepatu Boots Kulit",
        price: 599000,
        originalPrice: 799000,
        discount: 25,
        image: "https://images.unsplash.com/photo-1519864600265-abb23847ef2c?auto=format&fit=crop&w=800&q=80",
        badge: "LIMITED"
    },
    {
        id: 103,
        name: "Slip On Casual",
        price: 299000,
        originalPrice: 349000,
        discount: 14,
        image: "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=800&q=80"
    }
];

const accesoriesProducts = [
    {
        id: 201,
        name: "Jam Tangan Fashion",
        price: 199000,
        originalPrice: 249000,
        discount: 20,
        image: "https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b",
        badge: "NEW",
        description: "Jam tangan fashion dengan design minimalis modern. Water resistant hingga 30M. Tali kulit asli yang elegant.",
        sizes: ['Universal']
    },
    {
        id: 202,
        name: "Topi Baseball Hitam",
        price: 99000,
        originalPrice: 129000,
        discount: 23,
        image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=800&q=80"
    },
    {
        id: 203,
        name: "Kacamata Stylish",
        price: 149000,
        originalPrice: 199000,
        discount: 25,
        image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        badge: "HOT"
    }
];

// =====================
// VARIABEL KERANJANG & DOM
// =====================
let cart = [];
let cartCount = 0;
let cartTotal = 0;
let activeCategory = 'Semua';

const productsContainer = document.getElementById('products-container');
const cartItemsContainer = document.getElementById('cart-items');
const cartCountElement = document.querySelector('.cart-count');
const cartSubtotalElement = document.getElementById('cart-subtotal');
const cartTotalElement = document.getElementById('cart-total-price');
const cartIcon = document.getElementById('cart-icon');
const overlay = document.getElementById('overlay');
const cartPopup = document.getElementById('cart-popup');
const closeCart = document.getElementById('close-cart');
const continueBtn = document.querySelector('.continue-btn');
const checkoutBtn = document.querySelector('.checkout-btn');

// =====================
// FORMAT MATA UANG
// =====================
function formatCurrency(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

// =====================
// RENDER PRODUK UTAMA
// =====================
function renderProducts() {
    productsContainer.innerHTML = '';
    let filteredProducts = products;
    if (activeCategory !== 'Semua') {
        filteredProducts = products.filter(p => p.category === activeCategory);
    }
    filteredProducts.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
            ${product.discount ? `<div class="discount">-${product.discount}%</div>` : ''}
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <div class="product-price">
                    <div class="current-price">${formatCurrency(product.price)}</div>
                    ${product.originalPrice ? `<div class="original-price">${formatCurrency(product.originalPrice)}</div>` : ''}
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" data-id="${product.id}">Tambah ke Keranjang</button>
                </div>
            </div>
        `;
        card.querySelector('.add-to-cart').addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            const selectedProduct = products.find(p => p.id === productId);
            if (selectedProduct) showProductDetail(selectedProduct);
        });
        productsContainer.appendChild(card);
    });
}

// =====================
// RENDER SEPATU & AKSESORIS
// =====================
function renderSepatu() {
    const sepatuContainer = document.getElementById('sepatu-container');
    sepatuContainer.innerHTML = '';
    sepatuProducts.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-info">
                <div class="product-name">${product.name}</div>
                <div class="product-price">
                    <div class="current-price">${formatCurrency(product.price)}</div>
                    ${product.originalPrice ? `<div class="original-price">${formatCurrency(product.originalPrice)}</div>` : ''}
                    ${product.discount ? `<div class="discount">${product.discount}%</div>` : ''}
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" data-id="${product.id}">Tambah ke Keranjang</button>
                    <button class="wishlist-btn" title="Tambah ke Wishlist"><i class="far fa-heart"></i></button>
                </div>
            </div>
        `;
        card.querySelector('.add-to-cart').addEventListener('click', function() {
            showProductDetail(product);
        });
        sepatuContainer.appendChild(card);
    });
}

function renderAccesories() {
    const accesoriesContainer = document.getElementById('accesoris-container');
    accesoriesContainer.innerHTML = '';
    accesoriesProducts.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-info">
                <div class="product-name">${product.name}</div>
                <div class="product-price">
                    <div class="current-price">${formatCurrency(product.price)}</div>
                    ${product.originalPrice ? `<div class="original-price">${formatCurrency(product.originalPrice)}</div>` : ''}
                    ${product.discount ? `<div class="discount">${product.discount}%</div>` : ''}
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" data-id="${product.id}">Tambah ke Keranjang</button>
                    <button class="wishlist-btn" title="Tambah ke Wishlist"><i class="far fa-heart"></i></button>
                </div>
            </div>
        `;
        card.querySelector('.add-to-cart').addEventListener('click', function() {
            showProductDetail(product);
        });
        accesoriesContainer.appendChild(card);
    });
}

// =====================
// KERANJANG BELANJA
// =====================
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: 1
            });
        }
        cartCount++;
        cartTotal += product.price;
        updateCart();
        showNotification(`"${product.name}" ditambahkan ke keranjang`);
    }
}

function updateCart() {
    cartCountElement.textContent = cartCount;
    cartItemsContainer.innerHTML = '';
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p style="text-align: center; padding: 20px;">Keranjang belanja Anda kosong</p>';
        cartSubtotalElement.textContent = formatCurrency(0);
        cartTotalElement.textContent = formatCurrency(0);
        return;
    }
    let subtotal = 0;
    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        cartItem.innerHTML = `
            <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}">
            </div>
            <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${formatCurrency(item.price)}</div>
                <div class="cart-item-actions">
                    <div class="quantity-control">
                        <button class="quantity-btn minus" data-id="${item.id}">-</button>
                        <input type="text" class="quantity-input" value="${item.quantity}" readonly>
                        <button class="quantity-btn plus" data-id="${item.id}">+</button>
                    </div>
                    <div class="remove-item" data-id="${item.id}">Hapus</div>
                </div>
            </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    });
    cartSubtotalElement.textContent = formatCurrency(subtotal);
    cartTotalElement.textContent = formatCurrency(subtotal);

    // Event listener untuk kuantitas dan hapus
    document.querySelectorAll('.quantity-btn.minus').forEach(btn => {
        btn.addEventListener('click', function() {
            updateQuantity(parseInt(this.getAttribute('data-id')), -1);
        });
    });
    document.querySelectorAll('.quantity-btn.plus').forEach(btn => {
        btn.addEventListener('click', function() {
            updateQuantity(parseInt(this.getAttribute('data-id')), 1);
        });
    });
    document.querySelectorAll('.remove-item').forEach(btn => {
        btn.addEventListener('click', function() {
            removeFromCart(parseInt(this.getAttribute('data-id')));
        });
    });
}

function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        if (change > 0) {
            item.quantity++;
            cartCount++;
            cartTotal += item.price;
        } else {
            if (item.quantity > 1) {
                item.quantity--;
                cartCount--;
                cartTotal -= item.price;
            } else {
                removeFromCart(productId);
                return;
            }
        }
        updateCart();
    }
}

function removeFromCart(productId) {
    const itemIndex = cart.findIndex(item => item.id === productId);
    if (itemIndex !== -1) {
        const item = cart[itemIndex];
        cartCount -= item.quantity;
        cartTotal -= item.price * item.quantity;
        cart.splice(itemIndex, 1);
        updateCart();
        showNotification(`"${item.name}" dihapus dari keranjang`);
    }
}

// =====================
// NOTIFIKASI
// =====================
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #4CAF50;
        color: white;
        padding: 15px 25px;
        border-radius: 4px;
        z-index: 1000;
        animation: fadeInOut 3s;
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.5s forwards';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 500);
    }, 2500);
}

// =====================
// POPUP KERANJANG
// =====================
cartIcon.addEventListener('click', () => {
    overlay.style.display = 'block';
    cartPopup.style.display = 'flex';
    document.body.style.overflow = 'hidden';
});
closeCart.addEventListener('click', closeCartPopup);
overlay.addEventListener('click', closeCartPopup);
continueBtn.addEventListener('click', closeCartPopup);

function closeCartPopup() {
    overlay.style.display = 'none';
    cartPopup.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// =====================
// POPUP PEMBAYARAN
// =====================
let cartData = [];
let qrTimer;

function openPaymentPopup(cart) {
    cartData = cart;
    populateOrderSummary();
    calculateTotal();
    document.getElementById('paymentOverlay').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closePaymentPopup() {
    document.getElementById('paymentOverlay').style.display = 'none';
    document.body.style.overflow = 'auto';
    clearQRTimer();
    resetPaymentForm();
}

function populateOrderSummary() {
    const orderItems = document.getElementById('orderItems');
    orderItems.innerHTML = '';
    cartData.forEach(item => {
        const orderItem = document.createElement('div');
        orderItem.className = 'order-item';
        orderItem.innerHTML = `
            <div class="item-info">
                <div class="item-name">${item.name}</div>
                <div class="item-details">Ukuran: ${item.size || '-'} | Qty: ${item.quantity}</div>
            </div>
            <div class="item-price">Rp ${(item.price * item.quantity).toLocaleString('id-ID')}</div>
        `;
        orderItems.appendChild(orderItem);
    });
}

function calculateTotal() {
    let subtotal = 0;
    cartData.forEach(item => {
        subtotal += item.price * item.quantity;
    });
    const shippingCost = 12000;
    const taxRate = 0.01;
    const taxAmount = subtotal * taxRate;
    const total = subtotal + shippingCost + taxAmount;
    document.getElementById('subtotalAmount').textContent = `Rp ${subtotal.toLocaleString('id-ID')}`;
    document.getElementById('taxAmount').textContent = `Rp ${Math.round(taxAmount).toLocaleString('id-ID')}`;
    document.getElementById('totalAmount').textContent = `Rp ${Math.round(total).toLocaleString('id-ID')}`;
}

// Event: tombol checkout di keranjang
checkoutBtn.addEventListener('click', function(e) {
    e.preventDefault();
    if (cart.length === 0) {
        showNotification('Keranjang belanja Anda kosong');
        return;
    }
    openPaymentPopup(cart);
    closeCartPopup();
});

// Event: tombol batal & close
document.getElementById('cancelPaymentBtn').addEventListener('click', closePaymentPopup);
document.getElementById('closePaymentBtn').addEventListener('click', closePaymentPopup);
document.getElementById('paymentOverlay').addEventListener('click', function(e) {
    if (e.target === this) closePaymentPopup();
});

// Event: metode pembayaran QRIS
document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const qrSection = document.getElementById('qrSection');
        if (this.value === 'qris') {
            qrSection.classList.add('active');
            startQRTimer();
        } else {
            qrSection.classList.remove('active');
            clearQRTimer();
        }
    });
});

// QR Timer
function startQRTimer() {
    let timeLeft = 300;
    const timerElement = document.getElementById('qrTimer');
    qrTimer = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        if (timeLeft <= 0) {
            clearInterval(qrTimer);
            timerElement.textContent = 'Waktu Habis';
            timerElement.style.color = '#e74c3c';
        }
        timeLeft--;
    }, 1000);
}
function clearQRTimer() {
    if (qrTimer) {
        clearInterval(qrTimer);
        qrTimer = null;
    }
}

// Reset form pembayaran
function resetPaymentForm() {
    document.querySelectorAll('input[name="payment_method"]').forEach(radio => radio.checked = false);
    document.getElementById('qrSection').classList.remove('active');
    document.getElementById('successMessage').style.display = 'none';
    document.getElementById('errorMessage').style.display = 'none';
    document.getElementById('shippingAddress').value = '';
}

// Proses pembayaran (AJAX ke pembayaran.php)
document.getElementById('payButton').addEventListener('click', async function() {
    const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
    const shippingAddress = document.getElementById('shippingAddress').value.trim();
    if (!paymentMethod) {
        showPaymentMessage('Pilih metode pembayaran terlebih dahulu', 'error');
        return;
    }
    if (!shippingAddress || shippingAddress.length < 10) {
        showPaymentMessage('Alamat pengiriman harus diisi minimal 10 karakter', 'error');
        return;
    }
    if (cartData.length === 0) {
        showPaymentMessage('Keranjang kosong', 'error');
        return;
    }
    const payButton = document.getElementById('payButton');
    payButton.disabled = true;
    payButton.textContent = 'Memproses...';
    try {
        const formData = new FormData();
        formData.append('action', 'process_payment');
        formData.append('payment_method', paymentMethod.value);
        formData.append('shipping_address', shippingAddress);
        formData.append('cart_data', JSON.stringify(cartData));
        const response = await fetch('pembayaran.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        if (result.success) {
            showPaymentMessage(result.message, 'success');
            setTimeout(() => {
                closePaymentPopup();
                cart = [];
                cartCount = 0;
                cartTotal = 0;
                updateCart();
            }, 2000);
        } else {
            showPaymentMessage(result.message, 'error');
        }
    } catch (error) {
        showPaymentMessage('Terjadi kesalahan: ' + error.message, 'error');
    } finally {
        payButton.disabled = false;
        payButton.textContent = 'Bayar Sekarang';
    }
});

function showPaymentMessage(message, type) {
    const successMsg = document.getElementById('successMessage');
    const errorMsg = document.getElementById('errorMessage');
    successMsg.style.display = 'none';
    errorMsg.style.display = 'none';
    if (type === 'success') {
        successMsg.textContent = message;
        successMsg.style.display = 'block';
    } else {
        errorMsg.textContent = message;
        errorMsg.style.display = 'block';
    }
    setTimeout(() => {
        successMsg.style.display = 'none';
        errorMsg.style.display = 'none';
    }, 5000);
}

// =====================
// INISIALISASI
// =====================
renderProducts();
updateCart();
renderSepatu();
renderAccesories();