<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Koneksi database
$host = 'localhost';
$dbname = 'alista_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$user_id = $_SESSION['user_id'];
$response = ['success' => false, 'message' => ''];

// Handle AJAX request untuk proses pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'process_payment') {
        try {
            // Validasi input
            $payment_method = $_POST['payment_method'] ?? '';
            $shipping_address = trim($_POST['shipping_address'] ?? '');
            $cart_data = json_decode($_POST['cart_data'] ?? '[]', true);
            
            if (empty($payment_method) || empty($shipping_address) || empty($cart_data)) {
                throw new Exception('Data tidak lengkap');
            }
            
            // Validasi alamat
            if (strlen($shipping_address) < 10) {
                throw new Exception('Alamat pengiriman terlalu pendek');
            }
            
            $pdo->beginTransaction();
            
            // Hitung total dan validasi stock
            $subtotal = 0;
            $cart_items = [];
            
            foreach ($cart_data as $item) {
                // Cek produk dan stock
                $stmt = $pdo->prepare("SELECT p.*, ps.stock FROM products p 
                                     LEFT JOIN product_sizes ps ON p.product_id = ps.product_id AND ps.size = ?
                                     WHERE p.product_id = ?");
                $stmt->execute([$item['size'], $item['product_id']]);
                $product = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$product) {
                    throw new Exception('Produk tidak ditemukan: ' . $item['name']);
                }
                
                // Cek stock
                $available_stock = $product['stock'] ?: 0;
                if ($available_stock < $item['quantity']) {
                    throw new Exception('Stock tidak mencukupi untuk ' . $product['name'] . ' ukuran ' . $item['size']);
                }
                
                $item_total = $product['price'] * $item['quantity'];
                $subtotal += $item_total;
                
                $cart_items[] = [
                    'product_id' => $product['product_id'],
                    'name' => $product['name'],
                    'size' => $item['size'],
                    'quantity' => $item['quantity'],
                    'price' => $product['price'],
                    'total' => $item_total
                ];
            }
            
            // Hitung ongkir dan pajak
            $shipping_cost = 12000;
            $tax_rate = 0.01;
            $tax_amount = $subtotal * $tax_rate;
            $total_amount = $subtotal + $shipping_cost + $tax_amount;
            
            // Insert order
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, status, shipping_address, created_at) 
                                 VALUES (?, ?, 'processing', ?, NOW())");
            $stmt->execute([$user_id, $total_amount, $shipping_address]);
            $order_id = $pdo->lastInsertId();
            
            // Insert order items dan update stock
            foreach ($cart_items as $item) {
                // Insert order item
                $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, size, quantity, price) 
                                     VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$order_id, $item['product_id'], $item['size'], $item['quantity'], $item['price']]);
                
                // Update stock
                $stmt = $pdo->prepare("UPDATE product_sizes SET stock = stock - ? 
                                     WHERE product_id = ? AND size = ?");
                $stmt->execute([$item['quantity'], $item['product_id'], $item['size']]);
                
                // Update general stock
                $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE product_id = ?");
                $stmt->execute([$item['quantity'], $item['product_id']]);
            }
            
            // Hapus cart items (simulasi, karena cart dari JS)
            // Dalam implementasi nyata, Anda bisa hapus dari database cart
            
            $pdo->commit();
            
            $response['success'] = true;
            $response['message'] = 'Pembayaran berhasil diproses!';
            $response['order_id'] = $order_id;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $response['message'] = $e->getMessage();
        }
        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    }
}

// Get user data untuk alamat default
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran - Alista</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Overlay */
        .payment-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
            z-index: 1000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .payment-overlay.active {
            display: flex;
        }

        /* Pop-up container */
        .payment-popup {
            background: white;
            border-radius: 20px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
            animation: popupSlideIn 0.3s ease-out;
        }

        @keyframes popupSlideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        /* Header */
        .payment-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 20px 20px 0 0;
            position: relative;
        }

        .payment-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .payment-subtitle {
            opacity: 0.9;
            font-size: 14px;
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .close-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        /* Content */
        .payment-content {
            padding: 30px;
        }

        /* Order Summary */
        .order-summary {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .summary-title {
            font-weight: 700;
            font-size: 18px;
            color: #333;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        .summary-title::before {
            content: '🛍️';
            margin-right: 8px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #e9ecef;
        }

        .order-item:last-child {
            border-bottom: none;
        }

        .item-info {
            flex: 1;
        }

        .item-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 4px;
        }

        .item-details {
            font-size: 12px;
            color: #666;
        }

        .item-price {
            font-weight: 700;
            color: #667eea;
        }

        /* Price breakdown */
        .price-breakdown {
            background: white;
            border: 2px solid #f1f3f4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .price-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            padding: 8px 0;
        }

        .price-row.total {
            border-top: 2px solid #e9ecef;
            margin-top: 15px;
            padding-top: 15px;
            font-weight: 700;
            font-size: 18px;
            color: #333;
        }

        /* Shipping Address */
        .address-section {
            margin-bottom: 25px;
        }

        .section-title {
            font-weight: 700;
            font-size: 16px;
            color: #333;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
        }

        .section-title::before {
            content: '📍';
            margin-right: 8px;
        }

        .address-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 12px;
            font-size: 14px;
            resize: vertical;
            min-height: 100px;
            transition: all 0.3s ease;
        }

        .address-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        /* Payment Methods */
        .payment-methods {
            margin-bottom: 30px;
        }

        .payment-methods .section-title::before {
            content: '💳';
        }

        .payment-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .payment-option {
            position: relative;
        }

        .payment-option input[type="radio"] {
            display: none;
        }

        .payment-option label {
            display: block;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }

        .payment-option input[type="radio"]:checked + label {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.2);
        }

        .payment-icon {
            font-size: 24px;
            margin-bottom: 8px;
            display: block;
        }

        .payment-name {
            font-size: 12px;
            font-weight: 600;
            color: #333;
        }

        /* QR Code Section */
        .qr-section {
            display: none;
            text-align: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 15px;
            margin-top: 20px;
        }

        .qr-section.active {
            display: block;
        }

        .qr-code {
            width: 200px;
            height: 200px;
            background: white;
            border: 2px solid #ddd;
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 100px;
        }

        .qr-instructions {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .qr-timer {
            font-weight: 700;
            color: #e74c3c;
            font-size: 16px;
        }

        /* Action Buttons */
        .payment-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-cancel {
            background: #f8f9fa;
            color: #666;
            border: 2px solid #e9ecef;
        }

        .btn-cancel:hover {
            background: #e9ecef;
            color: #333;
        }

        .btn-pay {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-pay:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }

        .btn-pay:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* Loading */
        .loading {
            opacity: 0.6;
            pointer-events: none;
        }

        /* Success/Error Messages */
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
            display: none;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .payment-popup {
                margin: 10px;
                max-height: 95vh;
            }
            
            .payment-content {
                padding: 20px;
            }
            
            .payment-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .payment-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Payment Overlay -->
    <div class="payment-overlay" id="paymentOverlay">
        <div class="payment-popup">
            <!-- Header -->
            <div class="payment-header">
                <h2 class="payment-title">Pembayaran</h2>
                <p class="payment-subtitle">Selesaikan pesanan Anda</p>
                <button class="close-btn" onclick="closePaymentPopup()">×</button>
            </div>

            <!-- Content -->
            <div class="payment-content">
                <!-- Messages -->
                <div class="message success" id="successMessage"></div>
                <div class="message error" id="errorMessage"></div>

                <!-- Order Summary -->
                <div class="order-summary">
                    <h3 class="summary-title">Ringkasan Pesanan</h3>
                    <div id="orderItems">
                        <!-- Order items akan diisi oleh JavaScript -->
                    </div>
                </div>

                <!-- Price Breakdown -->
                <div class="price-breakdown">
                    <div class="price-row">
                        <span>Subtotal</span>
                        <span id="subtotalAmount">Rp 0</span>
                    </div>
                    <div class="price-row">
                        <span>Ongkos Kirim</span>
                        <span>Rp 12.000</span>
                    </div>
                    <div class="price-row">
                        <span>Pajak (1%)</span>
                        <span id="taxAmount">Rp 0</span>
                    </div>
                    <div class="price-row total">
                        <span>Total Pembayaran</span>
                        <span id="totalAmount">Rp 0</span>
                    </div>
                </div>

                <!-- Shipping Address -->
                <div class="address-section">
                    <h3 class="section-title">Alamat Pengiriman</h3>
                    <textarea 
                        class="address-input" 
                        id="shippingAddress" 
                        placeholder="Masukkan alamat lengkap pengiriman..."
                        required><?php echo htmlspecialchars($user['full_name'] ?? ''); ?>&#10;(Alamat belum tersedia, silakan lengkapi)</textarea>
                </div>

                <!-- Payment Methods -->
                <div class="payment-methods">
                    <h3 class="section-title">Metode Pembayaran</h3>
                    
                    <div class="payment-grid">
                        <div class="payment-option">
                            <input type="radio" id="ovo" name="payment_method" value="ovo">
                            <label for="ovo">
                                <span class="payment-icon">🟠</span>
                                <span class="payment-name">OVO</span>
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="dana" name="payment_method" value="dana">
                            <label for="dana">
                                <span class="payment-icon">🔵</span>
                                <span class="payment-name">DANA</span>
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="gopay" name="payment_method" value="gopay">
                            <label for="gopay">
                                <span class="payment-icon">🟢</span>
                                <span class="payment-name">GoPay</span>
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="shopeepay" name="payment_method" value="shopeepay">
                            <label for="shopeepay">
                                <span class="payment-icon">🟠</span>
                                <span class="payment-name">ShopeePay</span>
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="linkaja" name="payment_method" value="linkaja">
                            <label for="linkaja">
                                <span class="payment-icon">🔴</span>
                                <span class="payment-name">LinkAja</span>
                            </label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="qris" name="payment_method" value="qris">
                            <label for="qris">
                                <span class="payment-icon">📱</span>
                                <span class="payment-name">QRIS</span>
                            </label>
                        </div>
                    </div>

                    <!-- QR Code Section -->
                    <div class="qr-section" id="qrSection">
                        <div class="qr-code">📱</div>
                        <p class="qr-instructions">Scan QR Code dengan aplikasi e-wallet Anda</p>
                        <div class="qr-timer">Waktu tersisa: <span id="qrTimer">05:00</span></div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="payment-actions">
                    <button class="btn btn-cancel" onclick="closePaymentPopup()">Batal</button>
                    <button class="btn btn-pay" id="payButton" onclick="processPayment()">Bayar Sekarang</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let cartData = []; // Data cart dari halaman keranjang
        let qrTimer;

        // Fungsi untuk membuka pop-up pembayaran
        function openPaymentPopup(cart) {
            cartData = cart;
            populateOrderSummary();
            calculateTotal();
            document.getElementById('paymentOverlay').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Fungsi untuk menutup pop-up
        function closePaymentPopup() {
            document.getElementById('paymentOverlay').classList.remove('active');
            document.body.style.overflow = 'auto';
            clearQRTimer();
            resetForm();        }

        // Populate order summary
        function populateOrderSummary() {
            const orderItems = document.getElementById('orderItems');
            orderItems.innerHTML = '';

            cartData.forEach(item => {
                const orderItem = document.createElement('div');
                orderItem.className = 'order-item';
                orderItem.innerHTML = `
                    <div class="item-info">
                        <div class="item-name">${item.name}</div>
                        <div class="item-details">Ukuran: ${item.size} | Qty: ${item.quantity}</div>
                    </div>
                    <div class="item-price">Rp ${(item.price * item.quantity).toLocaleString('id-ID')}</div>
                `;
                orderItems.appendChild(orderItem);
            });
        }

        // Calculate total
        function calculateTotal() {
            let subtotal = 0;
            cartData.forEach(item => {
                subtotal += item.price * item.quantity;
            });

            const shippingCost = 12000;
            const taxRate = 0.01;
            const taxAmount = subtotal * taxRate;
            const total = subtotal + shippingCost + taxAmount;

            document.getElementById('subtotalAmount').textContent = `Rp ${subtotal.toLocaleString('id-ID')}`;
            document.getElementById('taxAmount').textContent = `Rp ${Math.round(taxAmount).toLocaleString('id-ID')}`;
            document.getElementById('totalAmount').textContent = `Rp ${Math.round(total).toLocaleString('id-ID')}`;
        }

        // Handle payment method change
        document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const qrSection = document.getElementById('qrSection');
                if (this.value === 'qris') {
                    qrSection.classList.add('active');
                    startQRTimer();
                } else {
                    qrSection.classList.remove('active');
                    clearQRTimer();
                }
            });
        });

        // QR Timer
        function startQRTimer() {
            let timeLeft = 300; // 5 minutes
            const timerElement = document.getElementById('qrTimer');
            
            qrTimer = setInterval(() => {
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                
                if (timeLeft <= 0) {
                    clearInterval(qrTimer);
                    timerElement.textContent = 'Waktu Habis';
                    timerElement.style.color = '#e74c3c';
                }
                timeLeft--;
            }, 1000);
        }

        function clearQRTimer() {
            if (qrTimer) {
                clearInterval(qrTimer);
                qrTimer = null;
            }
        }

        // Process payment
        async function processPayment() {
            // Validasi
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
            const shippingAddress = document.getElementById('shippingAddress').value.trim();
            
            if (!paymentMethod) {
                showMessage('Pilih metode pembayaran terlebih dahulu', 'error');
                return;
            }
            
            if (!shippingAddress || shippingAddress.length < 10) {
                showMessage('Alamat pengiriman harus diisi minimal 10 karakter', 'error');
                return;
            }
            
            if (cartData.length === 0) {
                showMessage('Keranjang kosong', 'error');
                return;
            }

            // Set loading state
            const payButton = document.getElementById('payButton');
            const popup = document.querySelector('.payment-popup');
            
            payButton.disabled = true;
            payButton.textContent = 'Memproses...';
            popup.classList.add('loading');

            try {
                // Send AJAX request
                const formData = new FormData();
                formData.append('action', 'process_payment');
                formData.append('payment_method', paymentMethod.value);
                formData.append('shipping_address', shippingAddress);
                formData.append('cart_data', JSON.stringify(cartData));

                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    showMessage(result.message, 'success');
                    setTimeout(() => {
                        closePaymentPopup();
                        // Clear cart di halaman utama
                        if (typeof clearCart === 'function') {
                            clearCart();
                        }
                        // Refresh halaman atau redirect
                        window.location.reload();
                    }, 2000);
                } else {
                    showMessage(result.message, 'error');
                }
            } catch (error) {
                showMessage('Terjadi kesalahan: ' + error.message, 'error');
            } finally {
                // Reset loading state
                payButton.disabled = false;
                payButton.textContent = 'Bayar Sekarang';
                popup.classList.remove('loading');
            }
        }

        // Show message
        function showMessage(message, type) {
            const successMsg = document.getElementById('successMessage');
            const errorMsg = document.getElementById('errorMessage');
            
            // Hide all messages
            successMsg.style.display = 'none';
            errorMsg.style.display = 'none';
            
            // Show appropriate message
            if (type === 'success') {
                successMsg.textContent = message;
                successMsg.style.display = 'block';
            } else {
                errorMsg.textContent = message;
                errorMsg.style.display = 'block';
            }
            
            // Auto hide after 5 seconds
            setTimeout(() => {
                successMsg.style.display = 'none';
                errorMsg.style.display = 'none';
            }, 5000);
        }

        // Reset form
        function resetForm() {
            document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
                radio.checked = false;
            });
            document.getElementById('qrSection').classList.remove('active');
            document.getElementById('successMessage').style.display = 'none';
            document.getElementById('errorMessage').style.display = 'none';
        }

        // Close popup when clicking outside
        document.getElementById('paymentOverlay').addEventListener('click', function(e) {
            if (e.target === this) {
                closePaymentPopup();
            }
        });

        // Example function to call from cart page
        // Contoh penggunaan dari halaman keranjang:
        /*
        const exampleCart = [
            {
                product_id: 1,
                name: 'Kaos Polos Premium',
                size: 'M',
                quantity: 2,
                price: 75000
            },
            {
                product_id: 2,
                name: 'Celana Jeans',
                size: 'L',
                quantity: 1,
                price: 150000
            }
        ];
        
        // Panggil fungsi ini dari halaman keranjang
        // openPaymentPopup(exampleCart);
        */
    </script>
</body>
</html>