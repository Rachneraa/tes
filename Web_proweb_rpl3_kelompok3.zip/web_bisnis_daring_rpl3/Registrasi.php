<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validasi input
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validasi field kosong
    if (empty($nama) || empty($email) || empty($password) || empty($confirmPassword)) {
        $_SESSION['error'] = "Semua field harus diisi!";
        header("Location: Registrasi.php");
        exit();
    }
    // Validasi password match
    else if ($password !== $confirmPassword) {
        $_SESSION['error'] = "Password tidak cocok!";
        header("Location: Registrasi.php");
        exit();
    }
    // Validasi password strength
    else if (
        strlen($password) < 8 || !preg_match("/[A-Z]/", $password) ||
        !preg_match("/[0-9]/", $password) || !preg_match("/[^A-Za-z0-9]/", $password)
    ) {
        $_SESSION['error'] = "Password harus minimal 8 karakter dan mengandung huruf besar, angka, dan simbol!";
        header("Location: Registrasi.php");
        exit();
    } else {
        try {
            // Check email exists
            $check_email = $conn->prepare("SELECT email FROM users WHERE email = ?");
            $check_email->bind_param("s", $email);
            $check_email->execute();
            $result = $check_email->get_result();

            if ($result->num_rows > 0) {
                $_SESSION['error'] = "Email sudah terdaftar!";
                header("Location: Registrasi.php");
                exit();
            } else {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Changed 'fullname' to 'full_name' to match database structure
                $stmt = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $nama, $email, $hashed_password);

                if ($stmt->execute()) {
                    $_SESSION['success'] = "Pendaftaran berhasil! Silakan login.";
                    header("Location: Login.php");
                    exit();
                } else {
                    throw new Exception("Pendaftaran gagal: " . $stmt->error);
                }
            }
        } catch (Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header("Location: Registrasi.php");
            exit();
        } finally {
            if (isset($stmt))
                $stmt->close();
            if (isset($check_email))
                $check_email->close();
            if (isset($conn))
                $conn->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Alista</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style/regis.css">
</head>

<body>
    <div class="register-container">
        <div class="register-left">
            <h1>Selamat Datang!</h1>
            <p>Bergabunglah dengan Alista dan nikmati pengalaman belanja fashion online yang mudah, aman, dan
                menyenangkan.</p>
            <div class="features">
                <div class="feature"><i class="fas fa-shipping-fast"></i> Pengiriman Cepat</div>
                <div class="feature"><i class="fas fa-tags"></i> Diskon & Promo Menarik</div>
                <div class="feature"><i class="fas fa-headset"></i> Support 24/7</div>
                <div class="feature"><i class="fas fa-user-shield"></i> Data Aman & Terlindungi</div>
            </div>
        </div>
        <div class="register-right">
            <div class="register-header">
                <h2>Buat Akun Baru</h2>
                <p>Isi data di bawah untuk mendaftar.</p>
                <?php
                if (isset($_SESSION['error'])) {
                    echo '<div class="notification error show">' . $_SESSION['error'] . '</div>';
                    unset($_SESSION['error']);
                }
                if (isset($_SESSION['success'])) {
                    echo '<div class="notification success show">' . $_SESSION['success'] . '</div>';
                    unset($_SESSION['success']);
                }
                ?>
            </div>
            <form action="" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="nama">Nama Lengkap</label>
                        <input type="text" id="nama" name="nama" required placeholder="Nama Lengkap">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required placeholder="Email">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Kata Sandi</label>
                        <input type="password" id="password" name="password" required placeholder="Kata Sandi">
                        <div class="password-strength" id="passwordStrength">
                            <div class="password-strength-bar" id="passwordStrengthBar"></div>
                        </div>
                        <div class="password-criteria" id="passwordCriteria">
                            <div class="criteria-item" id="criteria-length">Minimal 8 karakter</div>
                            <div class="criteria-item" id="criteria-upper">Huruf besar</div>
                            <div class="criteria-item" id="criteria-number">Angka</div>
                            <div class="criteria-item" id="criteria-special">Simbol</div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="confirmPassword">Konfirmasi Kata Sandi</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" required
                            placeholder="Ulangi Kata Sandi">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group full-width">
                        <button type="submit" class="btn-daftar">Daftar</button>
                    </div>
                </div>
                <div style="text-align:center; margin: 16px 0;">
                    <span>Atau daftar dengan</span>
                </div>
                <div style="display:flex; gap:12px; justify-content:center;">
                    <button type="button" class="btn-sosmed" style="background:#db4437;color:#fff;"><i
                            class="fab fa-google"></i> Google</button>
                    <button type="button" class="btn-sosmed" style="background:#4267B2;color:#fff;"><i
                            class="fab fa-facebook-f"></i> Facebook</button>
                </div>
                <div style="text-align:center; margin-top:20px;">
                    Sudah punya akun? <a href="Login.php">Masuk di sini</a>
                </div>
            </form>
        </div>
    </div>
    <script>
        // Password strength checker
        const password = document.getElementById('password');
        const passwordStrengthBar = document.getElementById('passwordStrengthBar');
        const passwordCriteria = {
            length: document.getElementById('criteria-length'),
            upper: document.getElementById('criteria-upper'),
            number: document.getElementById('criteria-number'),
            special: document.getElementById('criteria-special')
        };

        password.addEventListener('input', function () {
            const val = password.value;
            let strength = 0;

            // Cek kriteria
            if (val.length >= 8) {
                strength++;
                passwordCriteria.length.classList.add('valid');
            } else {
                passwordCriteria.length.classList.remove('valid');
            }
            if (/[A-Z]/.test(val)) {
                strength++;
                passwordCriteria.upper.classList.add('valid');
            } else {
                passwordCriteria.upper.classList.remove('valid');
            }
            if (/\d/.test(val)) {
                strength++;
                passwordCriteria.number.classList.add('valid');
            } else {
                passwordCriteria.number.classList.remove('valid');
            }
            if (/[^A-Za-z0-9]/.test(val)) {
                strength++;
                passwordCriteria.special.classList.add('valid');
            } else {
                passwordCriteria.special.classList.remove('valid');
            }

            // Update bar
            passwordStrengthBar.className = 'password-strength-bar';
            if (strength === 1) passwordStrengthBar.classList.add('strength-weak');
            else if (strength === 2) passwordStrengthBar.classList.add('strength-fair');
            else if (strength === 3) passwordStrengthBar.classList.add('strength-good');
            else if (strength === 4) passwordStrengthBar.classList.add('strength-strong');
            else passwordStrengthBar.style.width = '0';
        });
    </script>
</body>

</html>