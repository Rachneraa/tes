<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    try {
        $stmt = $conn->prepare("SELECT user_id, full_name, email, password FROM users WHERE email = ?");
        if (!$stmt)
            throw new Exception("Prepare failed: " . $conn->error);

        $stmt->bind_param("s", $email);
        if (!$stmt->execute())
            throw new Exception("Execute failed: " . $stmt->error);

        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['logged_in'] = true;
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $user['email'];

                if (isset($_POST['remember'])) {
                    setcookie('user_email', $email, time() + (86400 * 30), "/");
                }

                // Tambahkan debug
                // echo "Login berhasil, redirect ke index.php"; exit;

                header("Location: index.php");
                exit();
            } else {
                $_SESSION['error'] = "Password salah!";
            }
        } else {
            $_SESSION['error'] = "Email tidak terdaftar!";
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    } finally {
        if (isset($stmt))
            $stmt->close();
    }

    if (isset($_SESSION['error'])) {
        header("Location: Login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - Alista</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style/login.css">
</head>

<body>
    <a href="index.php" class="back-home">
        <i class="fas fa-arrow-left"></i> Kembali ke Beranda
    </a>

    <div class="login-container">
        <div class="login-left">
            <h1>Selamat Datang Kembali!</h1>
            <p>Masuk ke akun Anda untuk melanjutkan petualangan belanja dan menemukan koleksi fashion terbaru yang
                menawan.</p>
        </div>
        <div class="login-right">
            <div class="login-header">
                <h2>Masuk ke Akun</h2>
                <p>Silakan masukkan detail akun Anda</p>
                <?php
                if (isset($_SESSION['error'])) {
                    echo '<div class="notification error show">' . $_SESSION['error'] . '</div>';
                    unset($_SESSION['error']);
                }
                if (isset($_SESSION['success'])) {
                    echo '<div class="notification success show">' . $_SESSION['success'] . '</div>';
                    unset($_SESSION['success']);
                }
                ?>
            </div>
            <form method="POST" id="loginForm" action="">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="masukkan@email.com" required>
                </div>
                <div class="form-group">
                    <label for="password">Kata Sandi</label>
                    <input type="password" id="password" name="password" placeholder="Masukkan kata sandi" required>
                    <i class="fas fa-eye input-icon" id="togglePassword"></i>
                </div>
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember" id="remember">
                        Ingat saya
                    </label>
                    <a href="#" class="forgot-password" onclick="showForgotPassword()">Lupa kata sandi?</a>
                </div>
                <button type="submit" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i> Masuk
                </button>
            </form>
            <div class="divider">
                <span>atau masuk dengan</span>
            </div>
            <div class="social-login">
                <button class="social-btn" onclick="socialLogin('google')">
                    <i class="fab fa-google"></i> Google
                </button>
                <button class="social-btn" onclick="socialLogin('facebook')">
                    <i class="fab fa-facebook-f"></i> Facebook
                </button>
            </div>
            <div class="register-link">
                Belum punya akun? <a href="Registrasi.php">Daftar sekarang</a>
            </div>
        </div>
    </div>
    <script>
        // Notifikasi PHP auto-hide
        setTimeout(function () {
            var notif = document.querySelector('.notification.show');
            if (notif) notif.classList.remove('show');
        }, 3000);
    </script>
</body>

</html>