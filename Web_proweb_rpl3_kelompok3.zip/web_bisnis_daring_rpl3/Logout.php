<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    $_SESSION = array();
    session_destroy();
    if (isset($_COOKIE['user_email'])) {
        setcookie('user_email', '', time() - 3600, '/');
    }
    echo json_encode(['success' => true]);
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - Alista</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .logout-modal {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .logout-icon {
            font-size: 3rem;
            color: #ff6b6b;
            margin-bottom: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.8rem;
        }

        p {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .button-group {
            display: flex;
            gap: 15px;
            justify-content: center;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 120px;
        }

        .btn-logout {
            background: linear-gradient(45deg, #ff6b6b, #ff8e53);
            color: white;
        }

        .btn-cancel {
            background: #f8f9fa;
            color: #333;
            border: 2px solid #e0e0e0;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .btn-logout:hover {
            background: linear-gradient(45deg, #ff5252, #ff7043);
        }

        .btn-cancel:hover {
            background: #e9ecef;
        }

        .back-home {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .back-home:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
    </style>
</head>

<body>
    <a href="index.html" class="back-home">
        <i class="fas fa-arrow-left"></i> Kembali ke Beranda
    </a>

    <div class="logout-modal">
        <i class="fas fa-sign-out-alt logout-icon"></i>
        <h2>Konfirmasi Logout</h2>
        <p>Apakah Anda yakin ingin keluar dari akun Anda?</p>
        <div class="button-group">
            <button id="confirmLogout" class="btn btn-logout">Ya, Keluar</button>
            <button id="cancelLogout" class="btn btn-cancel">Batal</button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const confirmBtn = document.getElementById('confirmLogout');
            const cancelBtn = document.getElementById('cancelLogout');

            confirmBtn.addEventListener('click', function () {
                fetch('Logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'logout=true'
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            window.location.href = 'Login.php';
                        }
                    })
                    .catch(error => console.error('Error:', error));
            });

            cancelBtn.addEventListener('click', function () {
                window.location.href = 'index.html';
            });
        });
    </script>
</body>

</html>