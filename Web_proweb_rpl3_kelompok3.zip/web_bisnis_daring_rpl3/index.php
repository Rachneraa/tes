<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alista - Belanja Pakaian Online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style/style.css">

    <style>
        /* === Logout Popup Styles === */
        .logout-popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            z-index: 1001;
            width: 300px;
            max-width: 90%;
            text-align: center;
        }

        .logout-popup-content h3 {
            margin-bottom: 10px;
            font-size: 1.2rem;
        }

        .logout-popup-content p {
            font-size: 0.95rem;
            margin-bottom: 20px;
        }

        .logout-buttons {
            display: flex;
            justify-content: space-between;
        }

        .logout-buttons .btn {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            border: none;
            text-decoration: none;
            color: white;
        }

        .logout-buttons .cancel-btn {
            background-color: #777;
        }

        .logout-buttons .confirm-btn {
            background-color: #d9534f;
        }

        #logout-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
    </style>
</head>

<body>
    <!-- HEADER -->
    <header>
        <div class="header-top">
            <div class="logo">
                <img src="img/logo.png" alt="Alista Logo" class="logo-img">
                <span class="logo-text">Zoufy</span>
            </div>

            <div class="search-bar">
                <input type="text" placeholder="Cari produk, kategori, atau merek...">
                <button><i class="fas fa-search"></i> Cari</button>
            </div>

            <div class="header-icons">
                <div id="account-icon" class="dropdown">
                    <i class="fas fa-user"></i>
                    <div>
                        <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                    </div>
                    <div class="dropdown-content">
                        <a href="profile.php"><i class="fas fa-user-circle"></i> Profil</a>
                        <a href="#" class="logout-btn" id="logout-trigger">
                            <i class="fas fa-sign-out-alt"></i> Keluar
                        </a>
                    </div>
                </div>

                <div id="cart-icon">
                    <i class="fas fa-shopping-cart"></i>
                    <div>Keranjang</div>
                    <div class="cart-count">0</div>
                </div>
            </div>
        </div>

        <nav>
            <ul class="nav-links">
                <li><a href="#index"><i class="fas fa-home"></i> Beranda</a></li>
                <li><a href="#products"><i class="fas fa-fire"></i> Terbaru</a></li>
                <li><a href="#Pria"><i class="fas fa-tshirt"></i> Pria</a></li>
                <li><a href="#Wanita"><i class="fas fa-female"></i> Wanita</a></li>
                <li><a href="#Anak"><i class="fas fa-child"></i> Anak</a></li>
                <li><a href="#sepatu"><i class="fas fa-shoe-prints"></i> Sepatu</a></li>
                <li><a href="#accesoris"><i class="fas fa-shopping-bag"></i> Aksesoris</a></li>
            </ul>
        </nav>
    </header>

    <!-- HERO SECTION -->
    <section class="hero">
        <div class="hero-content">
            <h1>Style Anda, Kepribadian Anda</h1>
            <p>Temukan koleksi pakaian terbaru dengan kualitas premium dan harga terbaik</p>
            <a href="#categories" class="btn">Belanja Sekarang</a>
        </div>
    </section>

    <!-- PRODUK SECTION -->
    <section class="products">
        <h2 class="section-title">Koleksi Pakaian Terbaru</h2>
        <div class="filters">
            <button class="filter-btn active">Semua</button>
            <button class="filter-btn">Pria</button>
            <button class="filter-btn">Wanita</button>
            <button class="filter-btn">Anak</button>
        </div>
        <div class="products-grid" id="products-container">
            <!-- Produk akan di-generate oleh JavaScript -->
        </div>
    </section>

    <!-- SEPATU -->
    <section class="sepatu">
        <h2 class="section-title">Koleksi Sepatu Terbaru</h2>
        <div class="products-grid" id="sepatu-container">
            <!-- Produk sepatu akan di-generate oleh JavaScript -->
        </div>
    </section>

    <!-- ACCESORIS -->
    <section class="accesoris">
        <h2 class="section-title">Koleksi Aksesoris Terbaru</h2>
        <div class="products-grid" id="accesoris-container">
            <!-- Produk aksesoris akan di-generate oleh JavaScript -->
        </div>
    </section>

    <!-- CART POPUP -->
    <div class="overlay" id="overlay"></div>
    <div class="cart-popup" id="cart-popup">
        <div class="cart-header">
            <h2>Keranjang Belanja</h2>
            <button class="close-cart" id="close-cart">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="cart-content">
            <div class="cart-items" id="cart-items">
                <!-- Item keranjang akan di-generate oleh JavaScript -->
            </div>
            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span id="cart-subtotal">Rp 0</span>
                </div>
                <div class="summary-row">
                    <span>Pengiriman</span>
                    <span>Gratis</span>
                </div>
                <div class="summary-row total">
                    <span>Total</span>
                    <span id="cart-total-price">Rp 0</span>
                </div>
            </div>
        </div>
        <div class="cart-buttons">
            <button class="btn continue-btn">Lanjut Belanja</button>
            <button class="btn checkout-btn">Lanjut ke Pembayaran</button>
        </div>
    </div>

    <!-- Product Detail Popup -->
    <div class="product-detail-overlay" id="product-detail-overlay"></div>
    <div class="product-detail-popup" id="product-detail-popup">
        <div class="product-detail-header">
            <h2>Detail Produk</h2>
            <button class="close-detail" id="close-detail">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="product-detail-content">
            <div class="product-detail-image">
                <img src="" alt="" id="detail-image">
            </div>
            <div class="product-detail-info">
                <h3 id="detail-name"></h3>
                <div class="detail-price" id="detail-price"></div>
                <div class="product-description" id="detail-description"></div>
                <div class="size-selection">
                    <label>Pilih Ukuran:</label>
                    <div class="size-options" id="size-options"></div>
                </div>
                <div class="quantity-selection">
                    <label>Jumlah:</label>
                    <div class="quantity-control">
                        <button class="quantity-btn minus" id="detail-quantity-minus">-</button>
                        <input type="text" class="quantity-input" id="detail-quantity" value="1" readonly>
                        <button class="quantity-btn plus" id="detail-quantity-plus">+</button>
                    </div>
                </div>
                <button class="btn add-to-cart-detail" id="add-to-cart-detail">
                    Tambah ke Keranjang
                </button>
            </div>
        </div>
    </div>

    <!-- === LOGOUT POPUP === -->
    <div class="overlay" id="logout-overlay" style="display: none;"></div>

    <div class="logout-popup" id="logout-popup" style="display: none;">
        <div class="logout-popup-content">
            <h3>Konfirmasi Keluar</h3>
            <p>Apakah Anda yakin ingin keluar dari akun?</p>
            <div class="logout-buttons">
                <button class="btn cancel-btn" id="cancel-logout">Batal</button>
                <a href="Logout.php" class="btn confirm-btn">Keluar</a>
            </div>
        </div>
    </div>

    <!-- POPUP PEMBAYARAN -->
    <div class="payment-overlay" id="paymentOverlay" style="display:none;">
        <div class="payment-popup">
            <div class="payment-header">
                <h2 class="payment-title">Pembayaran</h2>
                <p class="payment-subtitle">Selesaikan pesanan Anda</p>
                <button class="close-btn" id="closePaymentBtn" type="button">&times;</button>
            </div>
            <div class="payment-content">
                <div class="message success" id="successMessage"></div>
                <div class="message error" id="errorMessage"></div>
                <div class="order-summary">
                    <h3 class="summary-title">Ringkasan Pesanan</h3>
                    <div id="orderItems"></div>
                </div>
                <div class="price-breakdown">
                    <div class="price-row">
                        <span>Subtotal</span>
                        <span id="subtotalAmount">Rp 0</span>
                    </div>
                    <div class="price-row">
                        <span>Ongkos Kirim</span>
                        <span>Rp 12.000</span>
                    </div>
                    <div class="price-row">
                        <span>Pajak (1%)</span>
                        <span id="taxAmount">Rp 0</span>
                    </div>
                    <div class="price-row total">
                        <span>Total Pembayaran</span>
                        <span id="totalAmount">Rp 0</span>
                    </div>
                </div>
                <div class="address-section">
                    <h3 class="section-title">Alamat Pengiriman</h3>
                    <textarea class="address-input" id="shippingAddress"
                        placeholder="Masukkan alamat lengkap pengiriman..." required></textarea>
                </div>
                <div class="payment-methods">
                    <h3 class="section-title">Metode Pembayaran</h3>
                    <div class="payment-grid">
                        <div class="payment-option">
                            <input type="radio" id="ovo" name="payment_method" value="ovo">
                            <label for="ovo"><span class="payment-icon">🟠</span><span
                                    class="payment-name">OVO</span></label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="dana" name="payment_method" value="dana">
                            <label for="dana"><span class="payment-icon">🔵</span><span
                                    class="payment-name">DANA</span></label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="gopay" name="payment_method" value="gopay">
                            <label for="gopay"><span class="payment-icon">🟢</span><span
                                    class="payment-name">GoPay</span></label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="shopeepay" name="payment_method" value="shopeepay">
                            <label for="shopeepay"><span class="payment-icon">🟠</span><span
                                    class="payment-name">ShopeePay</span></label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="linkaja" name="payment_method" value="linkaja">
                            <label for="linkaja"><span class="payment-icon">🔴</span><span
                                    class="payment-name">LinkAja</span></label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="qris" name="payment_method" value="qris">
                            <label for="qris"><span class="payment-icon">📱</span><span
                                    class="payment-name">QRIS</span></label>
                        </div>
                    </div>
                    <div class="qr-section" id="qrSection">
                        <div class="qr-code">📱</div>
                        <p class="qr-instructions">Scan QR Code dengan aplikasi e-wallet Anda</p>
                        <div class="qr-timer">Waktu tersisa: <span id="qrTimer">05:00</span></div>
                    </div>
                </div>
                <div class="payment-actions">
                    <button class="btn btn-cancel" id="cancelPaymentBtn" type="button">Batal</button>
                    <button class="btn btn-pay" id="payButton" type="button">Bayar Sekarang</button>
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer>
        <div class="footer-content">
            <!-- Konten footer seperti sebelumnya -->
        </div>
        <div class="copyright">
            &copy; 2023 Alista. Hak Cipta Dilindungi.
        </div>
    </footer>

    <!-- Script bawaan -->
    <script src="script/script.js"></script>

    <!-- Script tambahan untuk logout popup -->
    <script>
        document.getElementById('logout-trigger').addEventListener('click', function (e) {
            e.preventDefault();
            document.getElementById('logout-popup').style.display = 'block';
            document.getElementById('logout-overlay').style.display = 'block';
        });

        document.getElementById('cancel-logout').addEventListener('click', function () {
            document.getElementById('logout-popup').style.display = 'none';
            document.getElementById('logout-overlay').style.display = 'none';
        });

        document.getElementById('logout-overlay').addEventListener('click', function () {
            document.getElementById('logout-popup').style.display = 'none';
            document.getElementById('logout-overlay').style.display = 'none';
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const checkoutBtn = document.querySelector('.checkout-btn');
            const paymentOverlay = document.getElementById('paymentOverlay');
            const closePaymentBtn = document.getElementById('closePaymentBtn');

            if (checkoutBtn) {
                checkoutBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    paymentOverlay.style.display = 'block';
                });
            }
            if (closePaymentBtn) {
                closePaymentBtn.addEventListener('click', function () {
                    paymentOverlay.style.display = 'none';
                    paymentPopup.style.display = 'none';
                });
            }
            if (paymentOverlay) {
                paymentOverlay.addEventListener('click', function () {
                    paymentOverlay.style.display = 'none';
                    paymentPopup.style.display = 'none';
                });
            }
        });
    </script>
</body>

</html>