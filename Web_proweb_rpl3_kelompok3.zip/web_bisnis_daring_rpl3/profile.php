<?php
session_start();
require 'koneksi.php';

// Cek login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Ambil data user
$stmt = $conn->prepare("SELECT full_name, email, alamat FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($full_name, $email, $alamat);
$stmt->fetch();
$stmt->close();

// Proses update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $email_baru = trim($_POST['email']);
    $password = $_POST['password'];
    $alamat_baru = trim($_POST['alamat'] ?? '');

    if (empty($nama) || empty($email_baru)) {
        $error = "Nama dan email wajib diisi!";
    } else {
        // Cek email unik (jika email berubah)
        if ($email_baru !== $email) {
            $cek = $conn->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
            $cek->bind_param("si", $email_baru, $user_id);
            $cek->execute();
            $cek->store_result();
            if ($cek->num_rows > 0) {
                $error = "Email sudah digunakan!";
            }
            $cek->close();
        }
        if (!$error) {
            if (!empty($password)) {
                // Update dengan password baru
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET full_name=?, email=?, alamat=?, password=? WHERE user_id=?");
                $stmt->bind_param("ssssi", $nama, $email_baru, $alamat_baru, $hash, $user_id);
            } else {
                // Update tanpa password
                $stmt = $conn->prepare("UPDATE users SET full_name=?, email=?, alamat=? WHERE user_id=?");
                $stmt->bind_param("sssi", $nama, $email_baru, $alamat_baru, $user_id);
            }
            if ($stmt->execute()) {
                $success = "Profil berhasil diperbarui!";
                $_SESSION['full_name'] = $nama;
                $_SESSION['email'] = $email_baru;
                $email = $email_baru;
                $full_name = $nama;
                $alamat = $alamat_baru;
            } else {
                $error = "Gagal memperbarui profil!";
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya</title>
    <link rel="stylesheet" href="style/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<body>
    <a href="index.php" class="back-home">
        <i class="fas fa-arrow-left"></i> Kembali ke Beranda
    </a>
    <div class="profile-container">
        <div class="profile-header">
            <div class="profile-avatar">
                <svg viewBox="0 0 24 24">
                    <path
                        d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                </svg>
            </div>
            <h1 class="profile-title">Profil Saya</h1>
            <p class="profile-subtitle">Kelola informasi pribadi Anda</p>
        </div>

        <?php if ($success): ?>
            <div class="success-message" style="display:block;"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error-message" style="display:block;"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" id="profileForm">
            <div class="form-group">
                <label class="form-label" for="nama">Nama Lengkap</label>
                <input type="text" id="nama" name="nama" class="form-input"
                    value="<?php echo htmlspecialchars($full_name); ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-input"
                    value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="alamat">Alamat</label>
                <textarea id="alamat" name="alamat" class="form-input"
                    rows="3"><?php echo htmlspecialchars($alamat ?? ''); ?></textarea>
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Password Baru</label>
                <div class="password-group">
                    <input type="password" id="password" name="password" class="form-input"
                        placeholder="Kosongkan jika tidak ingin mengubah">
                    <button type="button" class="password-toggle" id="passwordToggle">👁️</button>
                </div>
            </div>
            <button type="submit" class="save-btn" id="saveBtn">
                Simpan Perubahan
            </button>
        </form>
    </div>
    <script>
        // Toggle password visibility
        document.getElementById('passwordToggle').addEventListener('click', function () {
            const passwordInput = document.getElementById('password');
            const toggleBtn = this;
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleBtn.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleBtn.textContent = '👁️';
            }
        });
    </script>
</body>

</html>